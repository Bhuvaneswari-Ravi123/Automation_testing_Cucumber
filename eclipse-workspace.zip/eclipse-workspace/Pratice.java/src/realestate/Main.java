package realestate;
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    int sqfeet=1500;
        int pricePersqft=5000;
        double baseprice=sqfeet*pricePersqft;
        double regtax=0.08*baseprice;
        double gst=0.03*baseprice;
        double total=baseprice+regtax+gst;
        ArrayList<String>areas=new ArrayList<>();
        areas.add("Flat Area: "+sqfeet+"sqft");
        areas.add("price Per sqft: "+pricePersqft);
        areas.add("baseprice: "+baseprice);
        areas.add("Registration Tax (8%):Rupess" +regtax);
        areas.add("GST(3%) :"+gst);
        areas.add("Total Price to pay :"+total);
        System.out.println("real estate calculation");
        for(String s:areas){
            System.out.println(s);
        }
		
	}
}



