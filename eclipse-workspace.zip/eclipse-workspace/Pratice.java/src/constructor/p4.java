package constructor;

public class p4 {
	int empid;
	String empname;
	float empsalary;
	p4(int empid,String empname,float empsalary){
		this.empid=empid;
		this.empname=empname;
		this.empsalary=empsalary;
	}
	void display() {
		System.out.println("Emp ID :"+empid);
		System.out.println("Emp Name :"+empname);
		System.out.println("Emp salary :"+empsalary);
		
	}
	public static void main(String[]args) {
		p4 emp=new p4(1000,"bhuvi",1000);
		emp.display();
		p4 emp1=new p4(10001,"bhuvi",1000);
		emp1.display();
	}


}
