package constructor;

public class p2 {
	int empid;
	String empname;
	float empsalary;
	void display() {
		System.out.println("Emp ID :"+empid);
		System.out.println("Emp Name :"+empname);
		System.out.println("Emp salary :"+empsalary);
		
	}
	public static void main(String[]args) {
		p2 emp=new p2();
		emp.display();
	}

}
