package constructor;

public class p3 {
	int empid;
	String empname;
	float empsalary;
	p3(){
		empid=100;
		empname="Bhuvi";
		empsalary=10000;
	}
	void display() {
		System.out.println("Emp ID :"+empid);
		System.out.println("Emp Name :"+empname);
		System.out.println("Emp salary :"+empsalary);
		
	}
	public static void main(String[]args) {
		p3 emp=new p3();
		emp.display();
	}


}
