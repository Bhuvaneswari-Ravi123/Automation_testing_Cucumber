package constructor;

public class p1 {
	void m1() {
		System.out.println("m1 method");
		
	}
	//default constructor
	p1(){
		System.out.println("0 arg constructor");
	}
	//passing arugument
	p1(int a){
		System.out.println("1 arg constructor");
		
	}
  public static void main(String[]args) {
	  p1 t=new p1();
	  t.m1();
	  p1 t1=new p1(10);
	  t1.m1();
  }
}
