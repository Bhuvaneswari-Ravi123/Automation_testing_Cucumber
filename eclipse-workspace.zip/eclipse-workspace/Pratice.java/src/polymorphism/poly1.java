package polymorphism;

public class poly1 {
	public static void main(String[]args) {
		System.out.println(10+20);
		System.out.println("bhuvi"+"r");
		System.out.println("bhuvi"+10);
		System.out.println("bhuvi"+10+"r");
	}

}
