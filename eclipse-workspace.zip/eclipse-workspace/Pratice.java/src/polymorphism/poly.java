package polymorphism;

public class poly {
	void m1(int a) {
		System.out.println("int m1 method" );
	}
	void m1(int a,int b) {
		System.out.println("int int m1 method");
		
	}
	void m1(char a) {
		System.out.println("char m1 method");
	}
public static void main(String[]args) {
	poly t=new poly();
	t.m1(10);
	t.m1('O');
	t.m1(10,11);
	
}
}
