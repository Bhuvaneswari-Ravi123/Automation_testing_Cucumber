package polymorphism;
//overriding
class shape{
	void draw() {
		System.out.println("no shape");
	}}
class circle extends shape{
	void draw() {
		System.out.println("drawing circle");
}
}
class rectangle extends shape{
	void draw() {
		System.out.println("drawing rectangle");
	}
}
class triangle extends shape{
	void draw() {
		System.out.println("Drawing triangle");
	}
}
public class Pol {
	public static void main(String[]args) {
		shape obj=new circle();
		shape obj1=new triangle();
		shape obj2=new rectangle();
		obj.draw();
		obj1.draw();
		obj2.draw();
		
	}
	

}
