package hash;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
public class Hash3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Create LinkedHashSet object.
				Set linkedHashSet = new LinkedHashSet();
		
				//Add objects to the LinkedHashSet.
				linkedHashSet.add("Samsung");
				linkedHashSet.add("Samsung");
				linkedHashSet.add("LG");
				linkedHashSet.add("Sony");
				linkedHashSet.add("Philips");
				linkedHashSet.add("Philips");
				linkedHashSet.add("Videocon");
		
				//Print the LinkedHashSet object.
				System.out.println("LinkedHashSet elements:");
				System.out.println(linkedHashSet);
		
				//Print the LinkedHashSet elements using iterator.
				Iterator iterator=linkedHashSet.iterator();
				System.out.println("LinkedHashSet elements " +
						"using iterator:");
				while(iterator.hasNext()){
				   System.out.println(iterator.next());
				}
	}
}










