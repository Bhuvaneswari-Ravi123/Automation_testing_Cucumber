package hash;

import java.util.Hashtable;
public class Hashtable2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hashtable<Integer,String> hashtable=new Hashtable<Integer,String>();
	     hashtable.put(200,"A");
	     hashtable.put(202,"B");
	     hashtable.put(201,"C");
	     hashtable.put(203,"D");
	     System.out.println("Initial Hashtable: "+hashtable);
	    
	     //Inserts, as the specified key-value pair is not exist in Hashtable as of now
	     hashtable.putIfAbsent(204,"E");
	     System.out.println("Updated Hashtable: "+hashtable);
	    
	    
	     //Returns the current value, as the specified key value pair already exist in Hashtable
	     hashtable.putIfAbsent(201,"C");
	     System.out.println("Updated Hashtable: "+hashtable);
		
		
	}
}
