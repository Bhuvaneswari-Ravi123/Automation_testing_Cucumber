package inheritance;
class q{
	q(){
		System.out.println("parent 0 arg constructor");
	}
	
}

public class in1 extends q{
	in1(){
		this(10);//it refer parametr of constructor
		System.out.println("child 0 arg constructor");
	}
	in1(int a){
		super();
		System.out.println("child 1 arg");
	}
public static void main(String[]args) {
	new in1();
}
}
