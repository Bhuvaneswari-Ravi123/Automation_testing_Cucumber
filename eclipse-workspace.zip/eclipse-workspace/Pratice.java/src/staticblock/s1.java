package staticblock;

public class s1 {
	{
	System.out.println("instance block1");

}
	{
		System.out.println("instance block 2");
		}
	static {
		System.out.println("static block 1");
		
	}
	static {
		System.out.println("static block 2");
	}
	s1(){
		System.out.println("0 argument");
	
	}
	s1(int a){
		System.out.println("1 arugument");
	}
	public static void main(String[]args) {
		new s1();
		new s1(10);
		
	}
	}
