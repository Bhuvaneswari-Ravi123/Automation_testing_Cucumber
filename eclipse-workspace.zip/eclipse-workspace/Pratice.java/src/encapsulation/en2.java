package encapsulation;

public class en2 {
	public static void main(String []args) {
		en1 person=new en1();
		person.setName("john");
		person.setAge(30);
		System.out.println("Name   "+person.getName());
		System.out.println("age   "+person.getAge());
	}

}
