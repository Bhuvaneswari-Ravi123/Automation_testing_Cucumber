package encapsulation;

public class Ent {
	public static void main(String[]args) {
		En pt=new En(2000,"yoyoa");
		System.out.println(pt.getModel());
		System.out.println(pt.getYear());
	}

}
