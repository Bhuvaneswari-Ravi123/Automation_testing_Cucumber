package encapsulation;

public class En {
	private int year;
	private String model;
	
	public int getYear() {
		return year;
	}
	
	public String getModel() {
		return model;
	}

	public En(int year, String model) {
		super();
		this.year = year;
		this.model = model;
	}

	
	

	
	


}
