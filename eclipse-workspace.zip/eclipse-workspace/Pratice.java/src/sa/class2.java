package sa;
import java.util.Scanner;
public class class2 {
	public static double age() {
		Scanner sc=new Scanner(System.in);
		boolean b=false;
		double in=0;
		while(!b) {
			System.out.println("enter yor age:<100");
			in=sc.nextDouble();
			if(in >0&&in<100) {
				b=true;
				System.out.println("this is correct age");
			}
			else {
				System.out.println("this is not correct age");
			}
			
		}
		return in;
	}
	public static void main(String []args) {
		class2 tn=new class2();
		tn.age();
	}

}
