package sample;

public class Instance_variables {
//instance variables(object-created object destroyed)
	int a=10;
	int b=20;
	int c=30;
	int d=40;
	public static void main(String[]args) {
		//instance variable create a object
		Instance_variables t=new Instance_variables();
		System.out.println(t.a);
		System.out.println(t.b);
t.m1();
	}
	//instance method
	void m1() {
		System.out.println(c);
		System.out.println(d);
	}
}
