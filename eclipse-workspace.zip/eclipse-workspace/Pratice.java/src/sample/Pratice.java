package sample;

public class Pratice {
	public static void main(String []args) {
		int a=25;
		int b=25;
		System.out.print(a+b);
		}
}

