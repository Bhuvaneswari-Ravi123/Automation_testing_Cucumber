package sample;

public class Static_Variable {
	static  int a=1000;
	static int b=2000;
	public static void main(String[]args) {
		System.out.println(Static_Variable.a);
		System.out.println(Static_Variable.b);
		Static_Variable t=new Static_Variable();
		t.m1();
	}
	void m1() {
		//static is call by class name
		System.out.println(Static_Variable.a);
		System.out.println(Static_Variable.b);
	}

}
