package telephone;

import java.util.*;
class Person{
 String name,surname,phone,email,place;
//constructor
public Person(String name,String surname, String phone,String email,String place)
{
  this.name=name;
  this.surname=surname;
  this.phone=phone;
  this.email=email;
  this.place=place;
}
}
  

public class Main
{
	public static void main(String[] args) {
	    //hold the object that be class
		List<Person>l=new LinkedList<>();
		//create person using constructor
		Person p1=new Person("Bhuvi","R","980123466","bhuv@gmail.com","salem");
		Person p2=new Person("Radhii","R","980123466","bhuv@gmail.com","salem");
		l.add(p1);
		l.add(p2);
		for(Person p:l){
		    System.out.println(p.name+" | "+p.surname+"  | "+p.phone+" |  "+p.email+" | "+p.place);
		}
		
	}
}


