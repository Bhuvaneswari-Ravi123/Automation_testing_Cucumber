package expection;

public class Cn {
	public static void main(String[]args) {
		try {
			int result=10/0;
			
		}
		catch(ArithmeticException e){
			System.out.println("exception caught"+e);
			
		}
		System.out.println("i will always execute");
	}

}
