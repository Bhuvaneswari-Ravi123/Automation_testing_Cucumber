package expection;

public class Fa {
	static void checkage(int age) {
		if(age<18) {
			throw new ArithmeticException("access denied: you must be at least 18 years old");
			
		}
		else {
			System.out.println("Access granted:you are old enough");
		}
	}
	public static void main(String[]args) {
		checkage(13);
	}

}
