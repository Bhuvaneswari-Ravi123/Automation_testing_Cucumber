package tree;

import java.util.Arrays;
import java.util.SortedSet;
import java.util.TreeSet;
public class Tree2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//printing arrays in sorted values
SortedSet<Integer> setNumbers = new TreeSet<>();
setNumbers.addAll(Arrays.asList(2, 1, 4, 3, 6, 5, 8, 7, 0, 9));
System.out.println("Original Set: " + setNumbers);
// first value in stack
Integer first = setNumbers.first();
System.out.println("First element: " + first);
// last element in stack
Integer last = setNumbers.last();
System.out.println("Last element: " + last);
// printing subset
SortedSet<Integer> subSet = setNumbers.subSet(3, 7);
System.out.println("Sub Set: " + subSet);
// printing head set
SortedSet<Integer> headSet = setNumbers.headSet(5);
System.out.println("Head Set: " + headSet);
//last five numbers
SortedSet<Integer> tailSet = setNumbers.tailSet(5);
System.out.println("Tail Set: " + tailSet);
	}
}

