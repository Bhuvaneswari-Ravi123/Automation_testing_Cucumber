package instance_block;

public class i2 {
	i2(){
		System.out.println("0 argument constructor");
	}
	i2(int a)
	{
		System.out.println("1 argument constructor"+a);
	}
	{
		System.out.println("instance blocks");
	}
	{
		System.out.println("instance block 1");
	}
public static void main(String[]args) {
	new i2();
	new i2(10);

}
}
