package instance_block;

public class i1 {
	i1(){
		System.out.println("0 argument constructor");
	}
	{
		System.out.println("instance blocks");
	}
	{
		System.out.println("instance block 1");
	}
public static void main(String[]args) {
	new i1();
}
}
