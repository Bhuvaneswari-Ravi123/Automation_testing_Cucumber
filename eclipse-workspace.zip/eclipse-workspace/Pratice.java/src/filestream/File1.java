package filestream;
import java.io.FileWriter;
import java.io.IOException;
public class File1 {
    public static void main(String[] args) {
        try {
            FileWriter writer = new FileWriter("C:\\\\Users\\\\LabsKraft\\\\Documents\\\\filewrite.txt");
            writer.write("Hello, world!\n");
            writer.write("This is a second line.");
            writer.close(); // Always close the writer
            System.out.println("Successfully written to the file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
