package Method;

public class Method1 {
	void m1(int a,char c) {
		System.out.println("m1 method");
		System.out.println(a);
		System.out.println(c);
		
		
	}
	static void m2(String s, double t) {
		System.out.println("m2 method");
		System.out.println(s);
		System.out.println(t);
	}
	public static void main(String[]args) {
		Method1 m=new Method1();
		m.m1(10, 'r');
		m.m2("ram",10.5);
	}

}
