package Method;

public class Methods {
	//instance method
	void m1() {
		System.out.println("m1 method");
		
	}
	//static method
	static void m2() {
		System.out.println("m2 method");
	}
	public static void main(String[]args) {
		Methods t=new Methods();
		t.m1();
		Methods.m2();
		
	}

}
