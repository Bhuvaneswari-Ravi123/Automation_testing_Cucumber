package abstraction;

 abstract class ab {
	 abstract void printInfo();

}
 class Employee extends ab{
	 void printInfo(){
		 String name="john";
		 int age=21;
		 float salary=222.2f;
		 System.out.println(name);
		 System.out.println(age);
		 System.out.println(salary);
	 }
 }
 class ab1{
	 public static void main(String []args) {
		 ab s=new Employee();
		 s.printInfo();
		 
	 }
 }
