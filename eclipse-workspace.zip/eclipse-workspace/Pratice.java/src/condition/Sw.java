package condition;

public class Sw {
	public static void main(String[]args) {
		int n=1;
		switch(n++) {
		case 1:
			System.out.println("hi team");
			break;
		
		case 2:
			System.out.println("hello team");
			break;
		
		default:
			System.out.println("bye team");
		
		}
	}

}
