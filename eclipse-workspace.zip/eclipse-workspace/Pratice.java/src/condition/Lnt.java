package condition;

public class Lnt {
	public static void main(String[]args) {
	int i=25;
	if(i==10) 
	{
		System.out.println("i is 10");
	}
	else if(i==20) {
		System.out.println("i is 20");
	}
	else {
		System.out.println("i is greater");
	}

}}
