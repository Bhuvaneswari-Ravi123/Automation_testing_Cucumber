package testcase;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageobjectmodel.CartPage;
import pageobjectmodel.CheckOut;
import pageobjectmodel.HomePage;
import pageobjectmodel.LoginPage;
import pageobjectmodel.Productpage;
import testsetup.Basetest;
import utility.excelutil;

public class Logintest1 extends Basetest {

    @DataProvider(name = "loginData")
    public Object[][] getLoginData() throws Exception {
        String path = "C:\\Users\\LabsKraft\\eclipse-workspace\\Selenium test\\Saucelabproject\\src\\test\\resources\\Logindata.xlsx";
        return excelutil.getExcelData(path, "Sheet1");
    }

    @Test(dataProvider = "loginData")
    public void testCheckoutFlow(String username, String password, String validity, String firstName, String lastName, String postalCode) throws InterruptedException {
        Basetest.initBrowser();
        try {
            LoginPage login = new LoginPage(Basetest.driver);
            login.login(username, password);

            if (validity.equalsIgnoreCase("valid")) {
                Assert.assertTrue(login.isLoggedIn(), "Login failed for valid user: " + username);

                Productpage products = new Productpage(Basetest.driver);
                products.addProducts();
                Assert.assertEquals(products.getCartCount(), 2, "Cart count mismatch");

                CartPage cart = new CartPage(Basetest.driver);
                cart.goToCheckout();

                CheckOut checkout = new CheckOut(Basetest.driver);
                checkout.enterDetails(firstName, lastName, postalCode);
                checkout.finishOrder();

                HomePage home = new HomePage(Basetest.driver);
                Assert.assertTrue(home.isConfirmed(), "Order not confirmed");

                home.goHomeAndLogout();
            } else {
                Assert.assertFalse(login.isLoggedIn(), "Login should fail for invalid user: " + username);
                Assert.assertTrue(login.getErrorMessage().length() > 0, "Expected error message not shown.");
            }
        } finally {
            Basetest.quitBrowser();
        }
    }
}
