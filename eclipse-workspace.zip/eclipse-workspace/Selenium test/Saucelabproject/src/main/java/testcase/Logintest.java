package testcase;
import org.junit.Assert;
import org.junit.Test;
import pageobjectmodel.CartPage;
import pageobjectmodel.CheckOut;
import pageobjectmodel.HomePage;
import pageobjectmodel.LoginPage;
import pageobjectmodel.Productpage;
import testsetup.Basetest;

public class Logintest {
	@Test
    public void testEndToEndCheckoutFlow() throws InterruptedException {
        Basetest.initBrowser();
        LoginPage login = new LoginPage(Basetest.driver);
        login.login("standard_user", "secret_sauce");
        Assert.assertTrue("Login failed", login.isLoggedIn());
        Productpage products = new Productpage(Basetest.driver);
        products.addProducts();
        Assert.assertEquals("Cart count mismatch", 2, products.getCartCount());
        CartPage cart = new CartPage(Basetest.driver);
        cart.goToCheckout();
        CheckOut checkout = new CheckOut(Basetest.driver);
        checkout.enterDetails("Bhuvi", "Ravi", "600001");
        checkout.finishOrder();
        HomePage home = new HomePage(Basetest.driver);
        Assert.assertTrue("Order not confirmed", home.isConfirmed());
        home.goHomeAndLogout();
        Basetest.quitBrowser();
    }
}









