package pageobjectmodel;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class HomePage {
    WebDriver driver;

    By confirmation = By.className("complete-header");
    By menuBtn = By.id("react-burger-menu-btn");
    By logoutLink = By.id("logout_sidebar_link");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isConfirmed() {
        return driver.findElement(confirmation).getText().contains("THANK YOU");
    }

    public void goHomeAndLogout() {
        driver.findElement(menuBtn).click();
        try {
            Thread.sleep(1000); // allow menu to open
        } catch (InterruptedException e) {}
        driver.findElement(logoutLink).click();
    }
}




