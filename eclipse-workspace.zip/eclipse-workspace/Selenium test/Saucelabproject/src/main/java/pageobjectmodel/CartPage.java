package pageobjectmodel;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class CartPage {
    WebDriver driver;

    By cartLink = By.className("shopping_cart_link");
    By checkoutBtn = By.id("checkout");

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    public void goToCheckout() {
        driver.findElement(cartLink).click();
        driver.findElement(checkoutBtn).click();
    }
}






