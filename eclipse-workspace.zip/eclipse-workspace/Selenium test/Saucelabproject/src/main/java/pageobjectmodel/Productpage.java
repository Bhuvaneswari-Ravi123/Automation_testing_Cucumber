package pageobjectmodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class Productpage {
    WebDriver driver;

    By addToCart1 = By.id("add-to-cart-sauce-labs-backpack");
    By addToCart2 = By.id("add-to-cart-sauce-labs-bike-light");
    By cartIcon = By.className("shopping_cart_badge");

    public Productpage(WebDriver driver) {
        this.driver = driver;
    }

    public void addProducts() {
        driver.findElement(addToCart1).click();
        driver.findElement(addToCart2).click();
    }

    public int getCartCount() {
        return Integer.parseInt(driver.findElement(cartIcon).getText());
    }
}







