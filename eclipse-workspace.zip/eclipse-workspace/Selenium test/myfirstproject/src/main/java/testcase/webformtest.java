package testcase;
/*import pageobject.Webform;
import testsetup.basetest;
public class webformtest extends basetest {
    public static void main(String[] args) {
    	webformtest test = new webformtest();
    	//call the basetest 
        test.setup();
        test.driver.get("https://www.selenium.dev/selenium/web/web-form.html");
        Webform loginPage = new Webform(test.driver);
       loginPage.submit("Student","password123","this mis");
        
    }
}*/
 


import pageobject.Webform;
import testsetup.basetest;

public class webformtest extends basetest {
    public static void main(String[] args) {
    	webformtest test = new webformtest();
        test.setup();
        test.driver.get("https://demoqa.com/automation-practice-form");
        Webform loginPage = new Webform(test.driver);
        loginPage.register("Bhuvana", "Ravi","bhuvana@30072002@gmail.com","890235789","Maths","tamilandu");
        // You can add validations here
        String currentUrl = test.driver.getCurrentUrl();
        System.out.println("Login success. Navigated to: " + currentUrl);
        test.tearDown();
    }
}


