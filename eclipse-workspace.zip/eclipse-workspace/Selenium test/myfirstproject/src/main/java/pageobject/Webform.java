package pageobject;
/*import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
public class Webform {
	WebDriver driver;
	//locator
	 private By Textinput=By.id("my-text-id");
	 private By Password=By.name("my-password");
	 private By Textarea=By.name("my-textarea");
	 private By Dropdown=By.name("my-select");
	 private By fileupload=By.name("my-file");
	 private By datepicker=By.name("my-date");
	 private By checkboxdata=By.name("my-datalist"); 
	 private By submit=By.cssSelector("button[type='submit']");
	 public Webform(WebDriver driver) {
		 this.driver=driver;
		 
	 }
	// Page actions
		public void enterUsername(String username) {
			driver.findElement(Textinput).sendKeys(username);
		}
		public void enterPassword(String password) {
			driver.findElement(Password).sendKeys(password);
		}
		public void enterTextarea(String textarea2) {
			driver.findElement(Textarea).sendKeys(textarea2);
		}
		
		public void clickdropdown(String value) {
             driver.findElement(By.id("dropdown"));
              Select select = new Select();
       // or use selectByValue(value)
         }

		public void fileupload() {
			((Object) driver.findElement(fileupload)).sendkeys();
		}

    public void uploadFile(String filePath) {
        driver.findElement(fileupload).sendKeys(filePath);
    



		public void submit(String user, String pass,String textarea) {
			enterUsername(user);
			enterPassword(pass);
			enterTextarea(textarea);
			driver.findElement(submit).click();
		}
	

}*/
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class Webform {
    WebDriver driver;
    // Locators
    private By firstNameField = By.id("firstName");
    private By lastNameField = By.id("lastName");
    private By emailField = By.id("userEmail");
    private By maleRadio = By.xpath("//*[@id=\"genterWrapper\"]/div[2]/div[1]/label");
    private By mobileField = By.id("userNumber");
    private By subjectsField = By.id("subjectsInput");
    private By hobbiesCheckbox = By.xpath("//*[@id=\"hobbiesWrapper\"]/div[2]/div[1]/label");
    private By currentAddressField = By.xpath("//*[@id=\"currentAddress\"]");
    private By submitButton = By.xpath("//*[@id=\"submit\"]");
    // Constructor
    public Webform(WebDriver driver) {
        this.driver = driver;
    }
    // Page actions
    public void enterFirstName(String fname) {
        driver.findElement(firstNameField).sendKeys(fname);
    }
    public void enterLastName(String lname) {
        driver.findElement(lastNameField).sendKeys(lname);
    }
    public void enterEmail(String email) {
        driver.findElement(emailField).sendKeys(email);
    }
    public void selectGenderMale() {
        driver.findElement(maleRadio).click();
    }
    public void enterMobile(String mobile) {
        driver.findElement(mobileField).sendKeys(mobile);
    }
    public void enterSubjects(String subject) {
       WebElement cc=driver.findElement(subjectsField);
        cc.sendKeys(subject);
        cc.sendKeys(Keys.ENTER);
    }
    public void selectHobbies() {
        driver.findElement(hobbiesCheckbox).click();
    }
    public void enterCurrentAddress(String address) {
        driver.findElement(currentAddressField).sendKeys(address);
    }
    public void clickSubmit() {
        driver.findElement(submitButton).click();
    }
    // Combined Action (optional)
    public void register(String fname, String lname, String email, String mobile, String subject, String address) {
        enterFirstName(fname);
        enterLastName(lname);
        enterEmail(email);
        selectGenderMale();
        enterMobile(mobile);
        enterSubjects(subject);
        selectHobbies();
        enterCurrentAddress(address);
        clickSubmit();
    }
	
}




 





