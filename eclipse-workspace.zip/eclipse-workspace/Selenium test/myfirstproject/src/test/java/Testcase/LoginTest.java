package Testcase;

import org.testng.annotations.Test;

public class LoginTest {
  @Test
  public void f() {
  }
}
