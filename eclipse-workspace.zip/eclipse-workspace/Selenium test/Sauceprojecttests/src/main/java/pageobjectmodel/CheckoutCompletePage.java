package pageobjectmodel;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class CheckoutCompletePage {
    WebDriver driver;

    private By orderConfirmation = By.xpath("//h2[contains(text(), 'Thank you')]");
    private By backToHomeButton = By.id("back-to-products");
    private By menuButton = By.id("react-burger-menu-btn");
    private By logoutLink = By.id("logout_sidebar_link");

    public CheckoutCompletePage(WebDriver driver) {
        this.driver = driver;
    }

    public String getOrderConfirmation() {
        return driver.findElement(orderConfirmation).getText();
    }

    public void backToHome() {
        driver.findElement(backToHomeButton).click();
    }

    public void openMenu() {
        driver.findElement(menuButton).click();
    }

    public void clickLogout() {
        driver.findElement(logoutLink).click();
    }
}