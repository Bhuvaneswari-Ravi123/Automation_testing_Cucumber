package pageobjectmodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class CheckoutPage {
  WebDriver driver;
  private By firstNameField = By.id("first-name");
  private By lastNameField = By.id("last-name");
  private By postalCodeField = By.id("postal-code");
  private By continueButton = By.id("continue");
  private By finishButton = By.id("finish");
  private By loginButton = By.id("login-button");
  private By errorMessage = By.xpath("//h3[@data-test='error']");
  public CheckoutPage(WebDriver driver) {
    this.driver = driver;
  }
  public void enterFirstName(String firstName) {
    driver.findElement(firstNameField).sendKeys(firstName);
  }
  public void enterLastName(String lastName) {
    driver.findElement(lastNameField).sendKeys(lastName);
  }
  public void enterPostalCode(String postalCode) {
    driver.findElement(postalCodeField).sendKeys(postalCode);
  }
  public void clickContinue() {
    driver.findElement(continueButton).click();
  }

  public CheckoutCompletePage proceedToFinish() {
	  driver.findElement(finishButton).click();
    
    return new CheckoutCompletePage(driver);
  }
  public String getErrorMessage() {
	    return driver.findElement(errorMessage).getText();
  }
}
