package pageobjectmodel;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.time.Duration;

public class SauceDemoTest {
    WebDriver driver;
    LoginPage loginPage;

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://www.saucedemo.com/");
        loginPage = new LoginPage(driver);
    }

    // 5 valid users + fixed checkout details (for simplicity)
    @DataProvider(name = "validCredentials")
    public Object[][] getValidCredentials() {
        return new Object[][] {
            {"standard_user", "secret_sauce", "John", "Doe", "12345"},
            {"problem_user", "secret_sauce", "Jane", "Smith", "54321"},
            {"performance_glitch_user", "secret_sauce", "Mike", "Tyson", "56789"},
            {"error_user", "secret_sauce", "Bruce", "Wayne", "78945"},
            {"locked_out_user", "secret_sauce", "Clark", "Kent", "65432"}  // Note: locked_out_user can't login but we keep it here for test - expect fail or handle it separately if needed
        };
    
    }
    // 5 invalid username/password combos
    @DataProvider(name = "invalidCredentials")
    public Object[][] getInvalidCredentials() {
        return new Object[][] {
            {"invalid_user", "wrong_pass"},
            {"standard_user", ""},
            {"", "secret_sauce"},
            {"wrong_user", "secret_sauce"},
            {"locked_out_user", "wrong_pass"}
        };
    }

    @Test(dataProvider = "validCredentials", priority = 1)
    public void testPositiveLoginAndCheckout(String username, String password, String firstName, String lastName, String postalCode) {
        // Login
        loginPage.enterUsername(username);
        loginPage.enterPassword(password);
        loginPage.clickLogin();

        // Check if login is successful (URL contains inventory)
        if (driver.getCurrentUrl().contains("inventory")) {
            ProductPage productPage = new ProductPage(driver);
            productPage.addToCart();

            CartPage cartPage = productPage.goToCart();
            CheckoutPage checkoutPage = cartPage.proceedToCheckout();

            checkoutPage.enterFirstName(firstName);
            checkoutPage.enterLastName(lastName);
            checkoutPage.enterPostalCode(postalCode);
            checkoutPage.clickContinue();

            CheckoutCompletePage completePage = checkoutPage.proceedToFinish();
            Assert.assertEquals(completePage.getOrderConfirmation(), "Thank you for your order!", "Order confirmation failed");

            completePage.backToHome();
            completePage.openMenu();
            completePage.clickLogout();

            Assert.assertTrue(driver.getCurrentUrl().contains("login"), "Logout failed");
            // Reset loginPage object for next test
            loginPage = new LoginPage(driver);
        } else {
            // Handle locked_out_user or unexpected login failure gracefully
            String errorMsg = loginPage.getErrorMessage();
            System.out.println("Login failed for user: " + username + " with error: " + errorMsg);
            Assert.fail("Login failed for valid user: " + username);
        }
    }

    @Test(dataProvider = "invalidCredentials", priority = 2)
    public void testNegativeLogin(String username, String password) {
        loginPage.enterUsername(username);
        loginPage.enterPassword(password);
        loginPage.clickLogin();

        String errorMsg = loginPage.getErrorMessage();
        System.out.println("Error message for invalid user '" + username + "': " + errorMsg);
        Assert.assertTrue(errorMsg.length() > 0, "Expected error message for invalid login but got none.");

        // Refresh page to reset for next test
        driver.navigate().refresh();
        loginPage = new LoginPage(driver);
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
