package pageobjectmodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class ProductPage {
  WebDriver driver;
  private By addToCartButton = By.xpath("//button[text()='Add to Cart']");
  private By cartIcon = By.id("shopping_cart_container");
  public ProductPage(WebDriver driver) {
    this.driver = driver;
  }
  public void addToCart() {
    driver.findElement(addToCartButton).click();
  }
  public CartPage goToCart() {
    driver.findElement(cartIcon).click();
    return new CartPage(driver);
  }


}
