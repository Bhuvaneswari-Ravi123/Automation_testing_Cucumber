package pageobjectmodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class CartPage {
  WebDriver driver;
  private By continueButton = By.id("continue-shopping");
  private By checkoutButton = By.id("checkout");
  public CartPage(WebDriver driver) {
    this.driver = driver;
  }
  public void clickCheckout() {
    driver.findElement(checkoutButton).click();
  }
  public CheckoutPage proceedToCheckout() {
    clickCheckout();
    return new CheckoutPage(driver);
  }
}
