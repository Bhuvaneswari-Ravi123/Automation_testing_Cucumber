package testsetup;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;
public class BaseTest {
  protected WebDriver driver;
  protected static final AtomicInteger testCount = new AtomicInteger(0);
  @BeforeClass
  public void setUp() {
    WebDriverManager.chromedriver().setup();
    driver = new ChromeDriver();
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    driver.get("https://www.saucedemo.com/");
  }
  @AfterClass
  public void tearDown() {
    while (testCount.get() < 10) {
      try {
        Thread.sleep(1000);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      }
    }
    if (driver != null) {
      System.out.println("Test Summary: Completed " + testCount.get() + " tests");
      driver.quit();
    }
  }}
