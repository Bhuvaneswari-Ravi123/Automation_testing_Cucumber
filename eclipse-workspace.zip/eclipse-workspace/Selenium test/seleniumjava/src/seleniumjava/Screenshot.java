package seleniumjava;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.*;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class Screenshot {
	public static void main(String[]args) throws InterruptedException, IOException {
		System.setProperty("Webdriver.chrome.driver","C://Users//LabsKraft//Downloads//chromedriver-win64//chromedriver.exe");
		WebDriver driver=new ChromeDriver();
	    driver.manage().window().maximize();
	    //open a webpage of google
	    driver.get("https://www.google.com");
	    //take a screenshot and save it in file
	    java.io.File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	 // Step 4: Define target file location
        File destination = new File("C:\\Users\\LabsKraft\\Pictures\\screenshot.png");
        // Step 5: Copy the screenshot to destination
        Files.copy(screenshot, destination);
        driver.quit();
       
	}

}
