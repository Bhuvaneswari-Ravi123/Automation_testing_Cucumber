package seleniumjava;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Formfilling {
	public static void main(String[]args) throws InterruptedException {
		System.setProperty("Webdriver.chrome.driver","C://Users//LabsKraft//Downloads//chromedriver-win64//chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://practicetestautomation.com/practice-test-login/");
		 Thread.sleep(2000);
		WebElement username=driver.findElement(By.name("username"));
		username.sendKeys("student");
		WebElement password=driver.findElement(By.name("password"));
		password.sendKeys("Password123");
		 // Step 3: Click the Submit button
        WebElement submitBtn = driver.findElement(By.id("submit"));
        submitBtn.click();
        Thread.sleep(2000);
        // Verify the result page contains submitted data
        String pageSource = driver.getPageSource();
        if (pageSource.contains("student")) {
            System.out.println("Button click successful, data submitted.");
        } else {
            System.out.println("Submission failed or data not found.");
        }
        // Step 5: Close browser
        driver.quit();
		
	}

}
