package seleniumjava;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Loginexample {
	public static void main(String[]args) throws InterruptedException {
		System.setProperty("Webdriver.chrome.driver","C://Users//LabsKraft//Downloads//chromedriver-win64//chromedriver.exe");
		WebDriver driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://the-internet.herokuapp.com/login");
	WebElement user=driver.findElement(By.id("username"));
	user.sendKeys("tomsmith");
	WebElement pass=driver.findElement(By.id("password"));
	pass.sendKeys("SuperSecretPassword!");
	WebElement button=driver.findElement(By.xpath("//*[@id='login']/button"));
	button.click();
	Thread.sleep(2000);
	driver.quit();
		
	}

}
