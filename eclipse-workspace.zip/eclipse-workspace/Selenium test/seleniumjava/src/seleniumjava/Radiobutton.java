package seleniumjava;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Radiobutton {
	public static void main(String[]args) throws InterruptedException {
		System.setProperty("Webdriver.chrome.driver","C://Users//LabsKraft//Downloads//chromedriver-win64//chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://testpages.herokuapp.com/styled/basic-html-form-test.html");
		 Thread.sleep(2000);
		 WebElement radiovalue=driver.findElement(By.xpath("//*[@id='HTMLFormElements']/table/tbody/tr[6]/td/input[1]"));
	    radiovalue.click();
	    Thread.sleep(3000);
	    System.out.println("clicked button1");
	    WebElement radiovalue1=driver.findElement(By.xpath("//*[@id=\"HTMLFormElements\"]/table/tbody/tr[6]/td/input[2]"));
	    Thread.sleep(1000);
	    System.out.println("clicked button2");
	    if(radiovalue1.isSelected()) {
	    	radiovalue1.click();
	    }
	    WebElement radio3=driver.findElement(By.xpath("//*[@id='HTMLFormElements']/table/tbody/tr[6]/td/input[3]"));
	   radio3.click();
	   System.out.println("clicked button3");
	   Thread.sleep(2000);
	    driver.quit();
	}

}
