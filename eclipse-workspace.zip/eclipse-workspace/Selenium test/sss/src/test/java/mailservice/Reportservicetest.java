package mailservice;

import org.testng.Assert;
import org.testng.annotations.*;
public class Reportservicetest {
	@test
	public void testgeneratorreport() {
		mailservice dummyemail=new dummy();
		reportservice reportservice=new reportservice(dummyemail);
		String result=reportservice.generatereport();
		Assert.assertEquals(result,"report generator");
	}

}
