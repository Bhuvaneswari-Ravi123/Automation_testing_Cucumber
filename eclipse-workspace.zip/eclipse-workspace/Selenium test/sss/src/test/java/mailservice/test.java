package mailservice;

public @interface test {

}
