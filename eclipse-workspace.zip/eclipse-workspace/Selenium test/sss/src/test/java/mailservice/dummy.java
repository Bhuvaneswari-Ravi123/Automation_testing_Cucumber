package mailservice;
//create dummy emails ervice
public class dummy  implements mailservice{

	@Override
	public void sendmail(String message) {
		// TODO Auto-generated method stub
		
	}
	
}
