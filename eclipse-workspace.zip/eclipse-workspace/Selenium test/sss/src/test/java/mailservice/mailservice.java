package mailservice;

public interface mailservice{//nothing is do here
	void sendmail(String message);
}
