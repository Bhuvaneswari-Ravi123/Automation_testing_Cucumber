package button;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.util.Set;
public class switchtab {
    public static void main(String[] args) throws InterruptedException {
        // Step 1: Setup ChromeDriver
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        // Step 2: Open the main page
        driver.get("https://the-internet.herokuapp.com/windows");
        System.out.println("Main Page Title: " + driver.getTitle());
        // Step 3: Click the link that opens a new tab
        WebElement link = driver.findElement(By.linkText("Click Here"));
        link.click();
        Thread.sleep(2000);
        // Step 4: Get window handles
        String originalWindow = driver.getWindowHandle();
        Set<String> allWindows = driver.getWindowHandles();
        // Step 5: Switch to the new window
        for (String windowHandle : allWindows) {
            if (!windowHandle.equals(originalWindow)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }
        // Step 6: Print new tab title
        System.out.println("New Tab Title: " + driver.getTitle());
        Thread.sleep(2000);
        // Step 7: Switch back to original window
        driver.switchTo().window(originalWindow);
        System.out.println("Back to Original Title: " + driver.getTitle());
        // Step 8: Close all windows
        driver.quit();
    }
}






