package phplogintestcase;
import org.openqa.selenium.support.PageFactory;

import PageObjectModel.PhpLogin;
import testsetup.Basetest;
public class Phptest extends Basetest {
	   public static void main(String[] args) {
		   Phptest test=new Phptest();
		   test.setup();
		   test.driver.get("https://www.phptravels.net/login");
		   PageFactory.initElements(driver, PhpLogin.class);
		   PhpLogin.Email.sendKeys("bhuvi3007@gmail.com");
		   PhpLogin.password.sendKeys("demouser");
		   PhpLogin.Login.click();
	   }
}
