package PageObjectModel;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class PhpLogin {
	@FindBy(name="email")
	public static WebElement Email;
	@FindBy(name="password")
	public static WebElement password;
	@FindBy(id="submitBTN")
	public static WebElement Login;
	
	

}
