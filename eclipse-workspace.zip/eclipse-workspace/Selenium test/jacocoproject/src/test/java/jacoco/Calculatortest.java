package jacoco;
import static org.testng.Assert.assertEquals;
import org.testng.annotations.Test;
@Test
public class Calculatortest {
	@Test
	public void testAdd() {
		calculator c =new calculator();
		assertEquals(5, c.add(2, 3));
	}
	@Test
	public void tesySubtract() {
		calculator c = new calculator();
		assertEquals(1, c.subtract(3, 2));
	}
}



